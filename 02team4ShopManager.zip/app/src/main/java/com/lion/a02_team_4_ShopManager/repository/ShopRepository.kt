package com.lion.a02_team_4_ShopManager.repository

class ShopRepository {
}