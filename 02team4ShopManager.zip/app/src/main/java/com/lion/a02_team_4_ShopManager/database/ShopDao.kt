package com.lion.a02_team_4_ShopManager.database

import androidx.room.Dao

@Dao
interface ShopDao {
}